/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.pacientes.gestor_pacientes.DAO;
import com.pacientes.gestor_pacientes.modelo.*;


/**
 *
 * @author previotto
 */
public interface IPacienteDAO extends CRUD<Paciente>{
    
}
