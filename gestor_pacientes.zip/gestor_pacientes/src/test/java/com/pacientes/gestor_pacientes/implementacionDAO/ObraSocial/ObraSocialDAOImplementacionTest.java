/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.pacientes.gestor_pacientes.implementacionDAO.ObraSocial;

import com.pacientes.gestor_pacientes.modelo.ObraSocial;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author previotto
 */
public class ObraSocialDAOImplementacionTest {
    
    public ObraSocialDAOImplementacionTest() {
    }
    
   

    /*@Test
    public void testObtenerLista() throws Exception {
        System.out.println("obtenerLista");
        ObraSocial objetoParametro = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        List<ObraSocial> expResult = null;
        List<ObraSocial> result = instance.obtenerLista(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtener() throws Exception {
        System.out.println("obtener");
        ObraSocial obraSocial = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        ObraSocial expResult = null;
        ObraSocial result = instance.obtener(obraSocial);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testActualizar() throws Exception {
        System.out.println("actualizar");
        ObraSocial obraSocial = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        instance.actualizar(obraSocial);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testEliminar() throws Exception {
        System.out.println("eliminar");
        ObraSocial obraSocial = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        instance.eliminar(obraSocial);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testInsertar() throws Exception {
        System.out.println("insertar");
        ObraSocial obraSocial = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        instance.insertar(obraSocial);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

  
    @Test
    public void testExisteObraSocialAsociada() throws Exception {
        System.out.println("existeObraSocialAsociada");
        ObraSocial obraSocial = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        boolean expResult = false;
        boolean result = instance.existeObraSocialAsociada(obraSocial);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtenerIdSinTelefono() throws Exception {
        System.out.println("obtenerIdSinTelefono");
        ObraSocial objetoParametro = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        int expResult = 0;
        int result = instance.obtenerIdSinTelefono(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtenerIdConUsuario() throws Exception {
        System.out.println("obtenerIdConUsuario");
        ObraSocial objetoParametro = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        int expResult = 0;
        int result = instance.obtenerIdConUsuario(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtenerId() throws Exception {
        System.out.println("obtenerId");
        ObraSocial objetoParametro = null;
        ObraSocialDAOImplementacion instance = new ObraSocialDAOImplementacion();
        int expResult = 0;
        int result = instance.obtenerId(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
