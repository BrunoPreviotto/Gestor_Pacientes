/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.pacientes.gestor_pacientes.implementacionDAO.Paciente;

import com.pacientes.gestor_pacientes.modelo.Paciente;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author previotto
 */
public class PacienteDAOImplementacionTest {
    
    public PacienteDAOImplementacionTest() {
    }
    
   /*
    @Test
    public void testObtener() throws Exception {
        System.out.println("obtener");
        Paciente pacienteParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        Paciente expResult = null;
        Paciente result = instance.obtener(pacienteParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testActualizar() throws Exception {
        System.out.println("actualizar");
        Paciente pacienteParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        instance.actualizar(pacienteParametro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testEliminar() throws Exception {
        System.out.println("eliminar");
        Paciente pacienteParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        instance.eliminar(pacienteParametro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testInsertar() throws Exception {
        System.out.println("insertar");
        Paciente paciente = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        instance.insertar(paciente);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testEsPacienteDeUsuarioActual() {
        System.out.println("esPacienteDeUsuarioActual");
        Paciente pacienteParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        boolean expResult = false;
        boolean result = instance.esPacienteDeUsuarioActual(pacienteParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtenerId() throws Exception {
        System.out.println("obtenerId");
        Paciente objetoParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        int expResult = 0;
        int result = instance.obtenerId(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testObtenerLista() throws Exception {
        System.out.println("obtenerLista");
        Paciente objetoParametro = null;
        PacienteDAOImplementacion instance = new PacienteDAOImplementacion();
        List<Paciente> expResult = null;
        List<Paciente> result = instance.obtenerLista(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
