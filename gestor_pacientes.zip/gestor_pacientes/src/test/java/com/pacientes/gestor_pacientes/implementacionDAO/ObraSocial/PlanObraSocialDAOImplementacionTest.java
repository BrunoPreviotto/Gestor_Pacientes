/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.pacientes.gestor_pacientes.implementacionDAO.ObraSocial;

import com.pacientes.gestor_pacientes.modelo.ObraSocial;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author previotto
 */
public class PlanObraSocialDAOImplementacionTest {
    
    public PlanObraSocialDAOImplementacionTest() {
    }
    
    

    /*
    @Test
    public void testObtenerLista() throws Exception {
        System.out.println("obtenerLista");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        List<ObraSocial> expResult = null;
        List<ObraSocial> result = instance.obtenerLista(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtener() throws Exception {
        System.out.println("obtener");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        ObraSocial expResult = null;
        ObraSocial result = instance.obtener(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testActualizar() throws Exception {
        System.out.println("actualizar");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        instance.actualizar(objetoParametro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testEliminar() throws Exception {
        System.out.println("eliminar");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        instance.eliminar(objetoParametro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testInsertar() throws Exception {
        System.out.println("insertar");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        instance.insertar(objetoParametro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testObtenerId() throws Exception {
        System.out.println("obtenerId");
        ObraSocial objetoParametro = null;
        PlanObraSocialDAOImplementacion instance = new PlanObraSocialDAOImplementacion();
        int expResult = 0;
        int result = instance.obtenerId(objetoParametro);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
